
 R	- change render mode

 T	- textures on/off

 L	- lighting on/off

 B	- bounding boxes on/off

 W	- water on/off

 C	- camera auto/free

 (free camera navigation: mouse, arrow keys, Pg Up/Down
  camera speed: ctrl [slower], shft [faster])
