
1. A minimum of 512 MB RAM and Windows XP is 
    recommended (1 GB to measure pure graphics card 
    power) !
2. Requires DX8.1 (and ensure that Direct3D release, 
    not debug, is selected) !
3. Your graphics card should have hardware support 
    for Pixel Shaders !
    (e.g. NVIDIA: GeForce 3 and GeForce 4 Ti,
     ATi: Radeon 8500)
4. AGP Aperture size:  This benchmark requires a total 
    video memory greater than 128 MB. This means that 
    if your graphics card has less than 128MB of memory, 
    then you MUST set your AGP Aperture size to 128MB 
    or greater. Anything less than this can result in 
    inconsistent results or stability issues.
5. Write protection must be disabled for all benchmark 
    files !