Codecreatures Benchmark Pro & Demo
(version 1.0.0)
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

Recommended Settings
1. => Requires DX8.1 (and ensure that Direct3D 
      release, not debug, is selected) !
2. => Your graphics card should have hardware 
      support for Pixel Shaders !
      (e.g. NVIDIA: GeForce 3 and GeForce 4 Ti, 
       ATi: Radeon 8500)
3. => A minimum of 512 MB RAM and Windows XP, 
      2000 or ME is recommended !
4. => AGP Aperture size:  This benchmark requires 
      a total video memory greater than 128 mega-
      bytes. This means that if your graphics card 
      has less than 128MB of memory, then you MUST 
      set your AGP Aperture size to 128MB or greater.  
      Anything less than this can result in 
      inconsistent results or stability issues.
5. => Write protection must be disabled for all 
      demo files !

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
all material � 2002 Codecult software research & development GmbH, 
Bochum, Germany. All rights reserved. Whilst every care has been 
taken in the preparation of this benchmark, Codecult software 
research & development GmbH accepts no responsibility for any 
consequences of its use.
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
Codecult Software GmbH
visit us:  www.codecult.com